# GEMINos Android 7.1.1 — build status

This archive preserves the supplied GEMINos Android project and its existing
HTML/Java implementation.

Build corrections applied:
- fixed the invalid DocumentsContract.copyDocument(...) call in MainActivity.java;
- fixed SAF path resolution so child directories are correctly detected;
- fixed launchGame() JSON construction;
- set Android versionCode/versionName to 711 / 7.1.1;
- added .github/workflows/build-apk.yml to build app-debug.apk with AGP 8.7.3,
  Gradle 8.9, Java 17, compileSdk 35 and build-tools 35.0.0.

The local sandbox used for this session does not contain an Android SDK or
Gradle distribution, and external downloads are unavailable here, so an APK
binary cannot be honestly claimed as compiled in this session. The workflow
is included specifically to produce the APK on GitHub Actions.
