package com.premiumcorp.geminos;

import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.view.Window;
import android.webkit.*;
import android.util.Base64;
import android.widget.Toast;

import org.json.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.KeySpec;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    private static final int REQ_TREE = 4101;
    private WebView webView;
    private Uri workspaceTree;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(18,20,24));
        w.setNavigationBarColor(Color.rgb(18,20,24));
        workspaceTree = loadTree();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7,17,30));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setSupportMultipleWindows(false); s.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new AndroidBridge(), "GEMINosAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return handleUrl(r.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url){ return handleUrl(Uri.parse(url)); }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(Uri u){
        if(u==null) return true;
        String s=u.getScheme();
        if("http".equalsIgnoreCase(s)||"https".equalsIgnoreCase(s)) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch(Exception ignored) {}
        return true;
    }

    private Uri loadTree(){ String x=getPreferences(0).getString("workspace_tree",null); return x==null?null:Uri.parse(x); }
    private void saveTree(Uri u){ workspaceTree=u; getPreferences(0).edit().putString("workspace_tree",u.toString()).apply(); }

    public class AndroidBridge {
        @JavascriptInterface public String systemInfo(){
            try { JSONObject o=new JSONObject(); o.put("platform","android"); o.put("arch",Build.SUPPORTED_ABIS.length>0?Build.SUPPORTED_ABIS[0]:"unknown"); o.put("version", "7.1.1"); o.put("sdk",Build.VERSION.SDK_INT); o.put("device",Build.MANUFACTURER+" "+Build.MODEL); o.put("workspace",workspaceTree==null?"":workspaceTree.toString()); return o.toString(); }
            catch(Exception e){return "{}";}
        }
        @JavascriptInterface public String chooseWorkspace(){ main.post(()->pickWorkspace()); return "PICKER"; }
        @JavascriptInterface public String getWorkspace(){ try{return new JSONObject().put("ok",true).put("root",workspaceTree==null?"":workspaceTree.toString()).toString();}catch(Exception e){return "{\"ok\":true,\"root\":\"\"}";} }
        @JavascriptInterface public String listFiles(String rel){ return listDocuments(rel); }
        @JavascriptInterface public String readTextFile(String rel){ return readDocument(rel,false); }
        @JavascriptInterface public String readMediaFile(String rel){ return readDocument(rel,true); }
        @JavascriptInterface public String writeTextFile(String rel,String content){ return writeDocument(rel,content); }
        @JavascriptInterface public String deleteFile(String rel){ return mutateDocument(rel,"delete",null); }
        @JavascriptInterface public String moveFile(String source,String destination){ return mutateDocument(source,"move",destination); }
        @JavascriptInterface public String copyFile(String source,String destination){ return copyDocument(source,destination); }
        @JavascriptInterface public String openWorkspaceFile(String rel){ return openDocument(rel); }
        @JavascriptInterface public String browserNavigate(String url){ return validUrl(url); }
        @JavascriptInterface public void browserBounds(String ignored) {}
        @JavascriptInterface public void browserVisible(boolean ignored) {}
        @JavascriptInterface public String terminalRun(String cmd){ return terminal(cmd); }
        @JavascriptInterface public String launchGame(){
            JSONArray a=new JSONArray();
            Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
            for(ResolveInfo ri:getPackageManager().queryIntentActivities(i,0)){
                String pkg=ri.activityInfo.packageName; if(pkg.equals(getPackageName()))continue;
                if(pkg.toLowerCase(Locale.ROOT).contains("roblox")||pkg.toLowerCase(Locale.ROOT).contains("game")){try{startActivity(getPackageManager().getLaunchIntentForPackage(pkg));return "{\"ok\":true,\"name\":\""+JSONObject.quote(String.valueOf(ri.loadLabel(getPackageManager())))+"}";}catch(Exception ignored){}}
            }
            return "{\"ok\":false,\"error\":\"Nessun gioco compatibile trovato tra le app installate.\"}";
        }
        @JavascriptInterface public String listLaunchableApps(){
            JSONArray arr=new JSONArray(); Intent intent=new Intent(Intent.ACTION_MAIN,null); intent.addCategory(Intent.CATEGORY_LAUNCHER);
            PackageManager pm=getPackageManager();
            try{for(ResolveInfo ri:pm.queryIntentActivities(intent,0)){String pkg=ri.activityInfo.packageName;if(pkg.equals(getPackageName()))continue;JSONObject o=new JSONObject();o.put("packageName",pkg);o.put("label",String.valueOf(ri.loadLabel(pm)));arr.put(o);}}catch(Exception ignored){}
            return arr.toString();
        }
        @JavascriptInterface public String launchApp(String packageName){try{Intent i=getPackageManager().getLaunchIntentForPackage(packageName);if(i==null)return "NOT_FOUND";startActivity(i);return "OK";}catch(Exception e){return "ERROR";}}
        @JavascriptInterface public String authHasAccount(){return getPreferences(0).contains("auth_hash")?"true":"false";}
        @JavascriptInterface public String authSetPassword(String p){try{byte[] salt=random(16);byte[] h=pbkdf(p,salt);getPreferences(0).edit().putString("auth_salt",b64(salt)).putString("auth_hash",b64(h)).apply();return "OK";}catch(Exception e){return "ERROR";}}
        @JavascriptInterface public String authVerify(String p){try{String s=getPreferences(0).getString("auth_salt",null),h=getPreferences(0).getString("auth_hash",null);if(s==null||h==null)return "NO_ACCOUNT";return MessageDigest.isEqual(Base64.decode(h,Base64.DEFAULT),pbkdf(p,Base64.decode(s,Base64.DEFAULT)))?"OK":"DENIED";}catch(Exception e){return "ERROR";}}
        @JavascriptInterface public String vaultStatus(){try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);return ks.containsAlias("GEMINOS_VAULT_KEY")?"READY":"UNINITIALIZED";}catch(Exception e){return "ERROR";}}

        @JavascriptInterface public String vaultInit(){try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("GEMINOS_VAULT_KEY")){KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder("GEMINOS_VAULT_KEY",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());kg.generateKey();}return "READY";}catch(Exception e){return "ERROR";}}
        @JavascriptInterface public String vaultSave(String key,String value){try{String enc=encrypt(value);getPreferences(0).edit().putString("vault:"+key,enc).apply();return "OK";}catch(Exception e){return "ERROR";}}
        @JavascriptInterface public String vaultRead(String key){try{String enc=getPreferences(0).getString("vault:"+key,null);return enc==null?"NOT_FOUND":decrypt(enc);}catch(Exception e){return "ERROR";}}
        @JavascriptInterface public String vaultDelete(String key){getPreferences(0).edit().remove("vault:"+key).apply();return "OK";}
        @JavascriptInterface public String vaultKeys(){JSONArray a=new JSONArray();Map<String,?> all=getPreferences(0).getAll();for(String k:all.keySet())if(k.startsWith("vault:"))a.put(k.substring(6));return a.toString();}
        @JavascriptInterface public String openrouterSetKey(String key){if(key==null||key.trim().isEmpty())return "ERROR";return vaultSave("openrouter_api_key",key.trim());}
        @JavascriptInterface public String openrouterHasKey(){return getPreferences(0).contains("vault:openrouter_api_key")?"true":"false";}
        @JavascriptInterface public String openrouterChat(String message){try{String key=vaultRead("openrouter_api_key");if(key==null||key.equals("NOT_FOUND")||key.equals("ERROR"))return "KEY_REQUIRED";URL u=new URL("https://openrouter.ai/api/v1/chat/completions");HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(60000);c.setDoOutput(true);c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("HTTP-Referer","https://geminos.local");c.setRequestProperty("X-Title","GEMINos SAIMIANNI");JSONObject body=new JSONObject();body.put("model","nvidia/nemotron-3-nano-30b-a3b");JSONArray msgs=new JSONArray();msgs.put(new JSONObject().put("role","system").put("content","You are SAIMIANNI, the assistant of GEMINos. Answer in Italian when the user writes Italian. Be concise, helpful and technically accurate."));msgs.put(new JSONObject().put("role","user").put("content",message==null?"":message));body.put("messages",msgs);OutputStream os=c.getOutputStream();os.write(body.toString().getBytes(StandardCharsets.UTF_8));os.close();InputStream in=(c.getResponseCode()>=400?c.getErrorStream():c.getInputStream());ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while(in!=null&&(n=in.read(b))>0)out.write(b,0,n);if(in!=null)in.close();String raw=new String(out.toByteArray(),StandardCharsets.UTF_8);if(c.getResponseCode()>=400)return "ERROR:"+raw;JSONObject r=new JSONObject(raw);return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content",raw);}catch(Exception e){return "ERROR:"+e.getMessage();}}
    }

    private void pickWorkspace(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,REQ_TREE); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQ_TREE&&c==RESULT_OK&&d!=null){try{getContentResolver().takePersistableUriPermission(d.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(Exception ignored){}saveTree(d.getData());toast("Cartella di lavoro selezionata");if(webView!=null)webView.evaluateJavascript("window.__geminosWorkspaceChanged && window.__geminosWorkspaceChanged("+JSONObject.quote(d.getData().toString())+")",null);}}
    private void toast(String s){main.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}

    private String validUrl(String u){ if(u==null)return "";u=u.trim();if(!u.matches("(?i)^https?://.*"))u="https://"+u;return u; }
    private byte[] random(int n){byte[] b=new byte[n];new SecureRandom().nextBytes(b);return b;}
    private byte[] pbkdf(String p,byte[] salt)throws Exception{KeySpec spec=new PBEKeySpec(p.toCharArray(),salt,120000,256);return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}
    private String b64(byte[] b){return Base64.encodeToString(b,Base64.NO_WRAP);}

    private DocumentInfo resolve(String rel){
        if(workspaceTree==null)return null; if(rel==null||rel.isEmpty()||".".equals(rel))return new DocumentInfo(workspaceTree,"",true);
        String[] parts=rel.replace('\\','/').split("/"); Uri cur=workspaceTree;
        for(String p:parts){if(p.isEmpty()||".".equals(p))continue;if("..".equals(p)){continue;} Uri next=findChild(cur,p);if(next==null)return null;cur=next;}
        return new DocumentInfo(cur,rel,false);
    }
    private Uri findChild(Uri parent,String name){CursorLike c=new CursorLike(); try{Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,DocumentsContract.getTreeDocumentId(parent)); android.database.Cursor q=getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null);if(q!=null){while(q.moveToNext()){if(name.equals(q.getString(1))) {String id=q.getString(0);q.close();return DocumentsContract.buildDocumentUriUsingTree(parent,id);}}q.close();}}catch(Exception ignored){}return null;}
    private String listDocuments(String rel){try{DocumentInfo d=resolve(rel);if(d==null)return "{\"ok\":false,\"error\":\"Cartella non trovata\"}";Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(workspaceTree,DocumentsContract.getTreeDocumentId(d.uri));JSONArray a=new JSONArray();android.database.Cursor q=getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE},null,null,DocumentsContract.Document.COLUMN_DISPLAY_NAME+" COLLATE NOCASE");if(q!=null){while(q.moveToNext()){JSONObject o=new JSONObject();String id=q.getString(0),name=q.getString(1),mime=q.getString(2);o.put("name",name);o.put("isDirectory",DocumentsContract.Document.MIME_TYPE_DIR.equals(mime));o.put("size",q.isNull(3)?0:q.getLong(3));o.put("path",rel.isEmpty()?name:rel+"/"+name);a.put(o);}q.close();}return new JSONObject().put("ok",true).put("items",a).toString();}catch(Exception e){return "{\"ok\":false,\"error\":\""+esc(e.getMessage())+"\"}";}}
    private String readDocument(String rel,boolean media){try{DocumentInfo d=resolve(rel);if(d==null||d.dir)return err("File non trovato");String mime=getMime(d.uri);if(media){InputStream mi=getContentResolver().openInputStream(d.uri);ByteArrayOutputStream mo=new ByteArrayOutputStream();byte[] mb=new byte[8192];int mn;while((mn=mi.read(mb))>0)mo.write(mb,0,mn);mi.close();return new JSONObject().put("ok",true).put("name",d.name).put("mime",mime).put("dataUrl","data:"+mime+";base64,"+b64(mo.toByteArray())).toString();}InputStream in=getContentResolver().openInputStream(d.uri);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();return new JSONObject().put("ok",true).put("path",rel).put("content",new String(out.toByteArray(),StandardCharsets.UTF_8)).toString();}catch(Exception e){return err(e.getMessage());}}
    private String writeDocument(String rel,String content){try{DocumentInfo d=resolve(rel);if(d==null){String n=rel.replace("\\","/");int slash=n.lastIndexOf("/");String parent=slash<0?"":n.substring(0,slash);String name=slash<0?n:n.substring(slash+1);DocumentInfo pd=resolve(parent);if(pd==null||!pd.dir)return err("Cartella non trovata");Uri u=DocumentsContract.createDocument(getContentResolver(),pd.uri,"text/plain",name);if(u==null)return err("Impossibile creare il file");d=new DocumentInfo(u,rel,false);}if(d.dir)return err("È una cartella");OutputStream out=getContentResolver().openOutputStream(d.uri,"wt");out.write(content.getBytes(StandardCharsets.UTF_8));out.close();return ok();}catch(Exception e){return err(e.getMessage());}}
    private String mutateDocument(String rel,String op,String dest){try{DocumentInfo d=resolve(rel);if(d==null||d.dir&&"delete".equals(op))return err("Elemento non trovato");if("delete".equals(op)){DocumentsContract.deleteDocument(getContentResolver(),d.uri);return ok();}if("move".equals(op)){String name=dest.replace('\\','/');int slash=name.lastIndexOf('/');String parent=slash<0?"":name.substring(0,slash);String newName=slash<0?name:name.substring(slash+1);DocumentInfo pd=resolve(parent);if(pd==null||!pd.dir)return err("Destinazione non trovata");Uri r=DocumentsContract.copyDocument(getContentResolver(),d.uri,pd.uri);if(r==null)return err("Copia non riuscita");try{DocumentsContract.renameDocument(getContentResolver(),r,newName);}catch(Exception ignored){}DocumentsContract.deleteDocument(getContentResolver(),d.uri);return ok();}return err("Operazione non supportata");}catch(Exception e){return err(e.getMessage());}}
    private String copyDocument(String source,String destination){try{DocumentInfo s=resolve(source);String name=destination.replace('\\','/');int slash=name.lastIndexOf('/');String parent=slash<0?"":name.substring(0,slash);String newName=slash<0?name:name.substring(slash+1);DocumentInfo pd=resolve(parent);if(s==null||pd==null)return err("Origine o destinazione non trovata");Uri r=DocumentsContract.copyDocument(getContentResolver(),s.uri,workspaceTree,DocumentsContract.getTreeDocumentId(pd.uri));if(!newName.equals(s.name))try{DocumentsContract.renameDocument(getContentResolver(),r,newName);}catch(Exception ignored){}return ok();}catch(Exception e){return err(e.getMessage());}}
    private String openDocument(String rel){try{DocumentInfo d=resolve(rel);if(d==null)return err("File non trovato");Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(d.uri,getMime(d.uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);return ok();}catch(Exception e){return err("Nessuna app disponibile per aprire il file");}}
    private String getMime(Uri u){String m=getContentResolver().getType(u);return m==null?"application/octet-stream":m;}
    private SecretKey vaultKey() throws Exception {KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);KeyStore.Entry e=ks.getEntry("GEMINOS_VAULT_KEY",null);if(!(e instanceof KeyStore.SecretKeyEntry)){throw new IllegalStateException("Vault non inizializzato");}return ((KeyStore.SecretKeyEntry)e).getSecretKey();}
    private String encrypt(String plain)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] iv=c.getIV(),ct=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));return b64(iv)+":"+b64(ct);}
    private String decrypt(String enc)throws Exception{String[] x=enc.split(":",2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,vaultKey(),new GCMParameterSpec(128,Base64.decode(x[0],Base64.DEFAULT)));return new String(c.doFinal(Base64.decode(x[1],Base64.DEFAULT)),StandardCharsets.UTF_8);}
    private String terminal(String cmd){String c=cmd==null?"":cmd.trim();if(c.isEmpty())return "";if(c.equalsIgnoreCase("clear"))return "\u0000CLEAR_TERMINAL";if(c.equalsIgnoreCase("help"))return "help\nls\npwd\ndate\nwhoami\nsysteminfo\necho <test>\nclear";if(c.equalsIgnoreCase("pwd"))return workspaceTree==null?"GEMINos://workspace/non-selected":workspaceTree.toString();if(c.equalsIgnoreCase("date"))return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ROOT).format(new Date());if(c.equalsIgnoreCase("whoami"))return "GEMINos user";if(c.equalsIgnoreCase("systeminfo"))return systemInfo();if(c.equalsIgnoreCase("ls"))return listDocuments("");if(c.startsWith("echo "))return c.substring(5);return "Comando non disponibile su Android: "+c;}
    private String ok(){return "{\"ok\":true}";} private String err(String s){return "{\"ok\":false,\"error\":\""+esc(s==null?"Errore":s)+"\"}";} private String esc(String s){return String.valueOf(s).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","");}
    private static class DocumentInfo {Uri uri;String path,name;boolean dir;DocumentInfo(Uri u,String p,boolean d){uri=u;path=p;dir=d;name=p.contains("/")?p.substring(p.lastIndexOf('/')+1):p;}}
    private static class CursorLike {}

    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.loadUrl("about:blank");webView.destroy();webView=null;}super.onDestroy();}
}
